#include "Button.h"
#include <iostream>
//#include "Word.h"

using namespace std;

Button::Button()
{
    width = 64;
    height = 64;
    button_value = 0;
    //ctor
}

Button::~Button()
{
    //dtor
    cout<<"\nButton Destroyed";
}

Button::Button(LTexture* image, float x, float y)
{
    spriteSheetTexture = image;

    button_value = 0;

    spriteClips.x = 0;
    spriteClips.y = 0;
    spriteClips.w = 0;
    spriteClips.h = 0;


    position.x = x;
    position.y = y;

    this->width = spriteClips.w;
    this->height = spriteClips.h;

}

void Button::menue_buttons(int my_x,int my_y,int my_w,int my_h,int x, int y)
{
    spriteClips.x = my_x;
    spriteClips.y = my_y;
    spriteClips.w = my_w;
    spriteClips.h = my_h;
    //setting position on screen
    this->position.x = x;
    this->position.y = y;
}

void Button::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{

    spriteSheetTexture->Render( position.x - width/2, position.y - height/2, &spriteClips, 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { position.x - width/2, position.y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }

}

void Button::SetPosition(Point& position)
{
    this->position.x = position.x - width/2;
    this->position.y = position.y - height/2;
}

void Button::SetPosition(int x, int y)
{
    this->position.x = x - width/2;
    this->position.y = y - height/2;
}

int Button::GetFrameWidth()
{
    return width;
}
int Button ::GetFrameHeight()
{
    return height;
}

