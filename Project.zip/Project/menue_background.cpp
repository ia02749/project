#include "menue_background.h"

#pragma once

#include <SDL.h>
#include <SDL_image.h>

#include <stdio.h>
#include <iostream>

#include"LTexture.h"
#include"Point.h"

using namespace std;


menue_background::menue_background()
{
    width = 1000;
    height = 700;
}

menue_background::menue_background(LTexture* image, float x, float y)
{
    spriteSheetTexture = image;

    gBackgroundTexture.x = 0;
    gBackgroundTexture.y = 0;
    gBackgroundTexture.w = 1000;
    gBackgroundTexture.h = 700;


    position.x = x;
    position.y = y;

    this->width = gBackgroundTexture.w;
    this->height = gBackgroundTexture.h;
}

menue_background::~menue_background()
{
    cout<<"dsctr called"<<endl;
}

void menue_background::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    spriteSheetTexture->Render( position.x - width/2, position.y - height/2, &gBackgroundTexture, 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { position.x - width/2, position.y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }

}


