#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include"LTexture.h"
#include"Point.h"


class Button
{
private:
    Point position;
    int button_value; //character_value;
    int width;
    int height;
    SDL_Rect spriteClips;
    LTexture* spriteSheetTexture;

public:
    Button();
    Button(LTexture* image, float x, float y);
    ~Button();
    virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
    void SetPosition(Point&);
    void SetPosition(int, int);
    int GetFrameWidth();
    int GetFrameHeight();
    int x_displacement;
    int y_displacement;
    void menue_buttons(int my_x,int my_y,int my_w,int my_h,int x, int y);

};
