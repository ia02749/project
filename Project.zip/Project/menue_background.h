#pragma once

#include <SDL.h>
#include <SDL_image.h>

#include <stdio.h>
#include <iostream>

#include"LTexture.h"
#include"Point.h"



class menue_background
{
private:
    Point position;
    int width;
    int height;
    SDL_Rect gBackgroundTexture;
    LTexture* spriteSheetTexture;

public:
    menue_background();
    menue_background(LTexture* image, float x, float y);
    ~menue_background();
    virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
};
